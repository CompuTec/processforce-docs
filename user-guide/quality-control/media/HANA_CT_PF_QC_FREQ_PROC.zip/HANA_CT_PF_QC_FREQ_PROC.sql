/*
counter_schema_code - nie powinno si� edytowa� bo sprfawdzam po nazwie czy istnieje (do tego post transact leci po Code)
update nie ma sensu jesli nie nedziemy modufikowa� / idea mia�abyc taka �e nie modyfikujemy tylko zmieniamy staus na nieaktywny i tworzymy nowy
co jak wejdzie penalty - to powino lecie� per TP a nie licznik - chyba sie rozjedzie
nie ma powi�zania ratingu z TP - brakuje p�l
nie powinno byc mo�liwo�ci dodania rewizji jak nie jest dodany itemcode / a mo�e to ok - lecimy rewizj� bez wzgl�du na itemcode
*/
--set schema "SPF_KSA_SPROC_8244";
--	drop procedure CT_PF_QC_FREQ_PROC;
--	drop table #OQCC_temp
create procedure CT_PF_QC_FREQ_PROC
(
in object_type nvarchar(20), 							--	SBO Object Type
in transaction_type nchar(1),							--	[A]dd, [U]pdate, [D]elete, [C]ancel, C[L]ose
in list_of_cols_val_tab_del nvarchar(255)				--	DocEntry
)
LANGUAGE SQLSCRIPT
AS

begin
declare rowcount int;
declare seq int;
--select "@CT_PF_OQCC_S".NEXTVAL into seq from dummy;
select ifnull(max("Code"),0) into seq from "@CT_PF_OQCC";

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if :object_type = N'CT_PF_CtScheme' and (:transaction_type = N'A' or :transaction_type = N'U') then			--	aktualny schemat do tabeli tymczasowej

	OQCC_temp_0 = 
		(
		select
			distinct
			null																		as "Name",							--	albo code i name uzupe�nia sie samo albo ja uzupe�niam jedno i drugie // ewemtualnie wciskam tu np:  "U_CounterSchemeCode"
			ctr."Code"																	as "U_CounterSchemeCode",
			case
				when ctr."U_BusinessPartner" = N'Y' then crd."CardCode"
				else null
			end																			as "U_BPCode",
			'20'																		as "U_Transaction",
			case
				when ctr."U_Item" = N'Y' then idt."U_ItemCode"
				else null
			end																			as "U_ItemCode",
			case
				when ctr."U_Revision" = N'Y' then dt1."U_Code"
				else null
			end																			as "U_RevisionCode",
			cast(now() as date)															as "U_CreateDate",
			extract(hour from now()) || extract(minute from now())						as "U_CreateTime",
			null																		as "U_UpdateDate",
			null																		as "U_UpdateTime",
			0																			as "U_Value",
			null																		as "U_Penalty",
			null																		as "U_PenaltyCounter",
			null																		as "U_LastTransaction",
			null																		as "U_LastTransactionId",
			N'Y'																		as "U_Status"
		from 
			"@CT_PF_OCTR" as ctr
			cross join
				"OCRD" as crd
				cross join
					"@CT_PF_OIDT" as idt
					inner join
						"@CT_PF_IDT1" as dt1
						on	dt1."Code" = idt."Code"	
		where
			ctr."Code" = :list_of_cols_val_tab_del
		and	ctr."U_Type" = N'OCC'
		and	ctr."U_UoMType" = N'T'
		and	ctr."U_GoodsReceiptPo" = N'Y'
		and	crd."U_QCQualCode" is not null
	);
	
	OQCC_temp = 
		(
		select
			right(concat('00000000', cast(ROW_NUMBER() OVER (ORDER BY "U_CounterSchemeCode") + :seq as nvarchar(8))),8)	as "Code",
			"Name",
			"U_CounterSchemeCode",
			"U_BPCode",
			"U_Transaction",
			"U_ItemCode",
			"U_RevisionCode",
			"U_CreateDate",
			"U_CreateTime",
			"U_UpdateDate",
			"U_UpdateTime",
			"U_Value",
			"U_Penalty",
			"U_PenaltyCounter",
			"U_LastTransaction",
			"U_LastTransactionId",
			"U_Status"
		from
			:OQCC_temp_0
		);
end if;

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if :object_type = N'CT_PF_CtScheme' and :transaction_type = N'U' then				--	jesli update / sprawdza czy schemat sie zmieni� -> jesli tak flaga na N i insert aktualnego

	select
		count(*) into rowcount
	from
		(
		select
			*
		from 
			:OQCC_temp
		) as act
		full join
			(
			select
				"U_CounterSchemeCode",
				"U_BPCode",
				"U_Transaction",
				"U_ItemCode",
				"U_RevisionCode",
				"U_Status"
			from 
				"@CT_PF_OQCC"
			where
				"U_CounterSchemeCode" = :list_of_cols_val_tab_del
			and	"U_Status" = N'Y'
			) as prev
			on	ifnull(act."U_BPCode",N'#null')			= ifnull(prev."U_BPCode",N'#null')
			and	ifnull(act."U_Transaction",N'#null')	= ifnull(prev."U_Transaction",N'#null')
			and	ifnull(act."U_ItemCode",N'#null')		= ifnull(prev."U_ItemCode",N'#null')
			and	ifnull(act."U_RevisionCode",N'#null')	= ifnull(prev."U_RevisionCode",N'#null')
			and	ifnull(act."U_Status",N'#null')			= ifnull(prev."U_Status",N'#null')
		where
			act."U_CounterSchemeCode" is null
		or	prev."U_CounterSchemeCode" is null;

	if :rowcount != 0 then 
		update
			"@CT_PF_OQCC"
		set
			"U_Status" = N'N'
		where
			"U_CounterSchemeCode" = :list_of_cols_val_tab_del;

		insert into
			"@CT_PF_OQCC"
		select
			*
		from
			:OQCC_temp;
	end if;

end if;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if :object_type = N'CT_PF_CtScheme' and :transaction_type = N'A' then				--	insert aktualnego

	insert into
		"@CT_PF_OQCC"
	select
		*
	from
		:OQCC_temp;

end if;
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if :object_type = N'20' and :transaction_type = N'A' then							--	zwi�kszenie licznika

	update
		qcc
	set
		qcc."U_Value"				= qcc."U_Value" + 1,
		qcc."U_LastTransaction"		= obj_20."ObjType",
		qcc."U_LastTransactionId"	= obj_20."DocEntry",
		qcc."U_UpdateDate"			= cast(now() as date),
		qcc."U_UpdateTime"			= extract(hour from now()) || extract(minute from now())
	from
		"@CT_PF_OQCC" as qcc
		inner join
			(
			select
				h."ObjType",
				h."DocEntry",
				h."CardCode",
				l."ItemCode",
				l."U_Revision"
			from
				PDN1 as l
				inner join
					OPDN as h
					on	l."DocEntry" = h."DocEntry"
			where
				h."DocEntry" = :list_of_cols_val_tab_del
			) as obj_20
			on	ifnull(qcc."U_BPCode",N'#null')				= case when qcc."U_BPCode" is null then N'#null' else obj_20."CardCode" end
			and	ifnull(qcc."U_Transaction",N'#null')		= case when qcc."U_Transaction" is null then N'#null' else obj_20."ObjType" end
			and	ifnull(qcc."U_ItemCode",N'#null')			= case when qcc."U_ItemCode" is null then N'#null' else obj_20."ItemCode" end
			and	ifnull(qcc."U_RevisionCode",N'#null')		= case when qcc."U_RevisionCode" is null then N'#null' else obj_20."U_Revision" end
	where
		qcc."U_Status" = N'Y';

end if;
end;
