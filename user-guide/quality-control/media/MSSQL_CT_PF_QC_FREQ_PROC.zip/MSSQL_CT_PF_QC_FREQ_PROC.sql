/*
counter_schema_code - nie powinno si� edytowa� bo sprfawdzam po nazwie czy istnieje (do tego post transact leci po Code)
update nie ma sensu jesli nie nedziemy modufikowa� / idea mia�abyc taka �e nie modyfikujemy tylko zmieniamy staus na nieaktywny i tworzymy nowy
co jak wejdzie penalty - to powino lecie� per TP a nie licznik - chyba sie rozjedzie
nie ma powi�zania ratingu z TP - brakuje p�l
nie powinno byc mo�liwo�ci dodania rewizji jak nie jest dodany itemcode / a mo�e to ok - lecimy rewizj� bez wzgl�du na itemcode
*/

--	drop procedure CT_PF_QC_FREQ_PROC
alter procedure CT_PF_QC_FREQ_PROC
(
@object_type nvarchar(20), 							--	SBO Object Type
@transaction_type nchar(1),							--	[A]dd, [U]pdate, [D]elete, [C]ancel, C[L]ose
@list_of_cols_val_tab_del nvarchar(255)				--	DocEntry
)
as

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if @object_type = N'CT_PF_CtScheme' and @transaction_type in (N'A', N'U')			--	aktualny schemat do tabeli tymczasowej
begin
	select
		distinct
	--	null																		as "Code",
		null																		as "Name",							--	albo code i name uzupe�nia sie samo albo ja uzupe�niam jedno i drugie // ewemtualnie wciskam tu np:  "U_CounterSchemeCode"
		ctr."Code"																	as "U_CounterSchemeCode",
		case
			when ctr."U_BusinessPartner" = N'Y' then crd."CardCode"
			else null
		end																			as "U_BPCode",
		'20'																		as "U_Transaction",
		case
			when ctr."U_Item" = N'Y' then idt."U_ItemCode"
			else null
		end																			as "U_ItemCode",
		case
			when ctr."U_Revision" = N'Y' then dt1."U_Code"
			else null
		end																			as "U_RevisionCode",
		cast(getdate() as date)														as "U_CreateDate",
		replace(convert(varchar(5), getdate(), 108),':','')							as "U_CreateTime",
		null																		as "U_UpdateDate",
		null																		as "U_UpdateTime",
		0																			as "U_Value",
		null																		as "U_Penalty",
		null																		as "U_PenaltyCounter",
		null																		as "U_LastTransaction",
		null																		as "U_LastTransactionId",
		N'Y'																		as "U_Status"
	into
		#OQCC_temp
	from 
		"@CT_PF_OCTR" as ctr
		cross join
			"OCRD" as crd
			cross join
				"@CT_PF_OIDT" as idt
				inner join
					"@CT_PF_IDT1" as dt1
					on	dt1."Code" = idt."Code"	
	where
		ctr."Code" = @list_of_cols_val_tab_del
	and	ctr."U_Type" = N'OCC'
	and	ctr."U_UoMType" = N'T'
	and	ctr."U_GoodsReceiptPo" = N'Y'
	and	crd."U_QCQualCode" is not null
end
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if @object_type = N'CT_PF_CtScheme' and @transaction_type = N'U'				--	jesli update / sprawdza czy schemat sie zmieni� -> jesli tak flaga na N i insert aktualnego
begin
	if exists
		(
		select
			*
		from
			(
			select
				*
			from 
				#OQCC_temp
			) as act
			full join
				(
				select
					"U_CounterSchemeCode",
					"U_BPCode",
					"U_Transaction",
					"U_ItemCode",
					"U_RevisionCode",
					"U_Status"
				from 
					"@CT_PF_OQCC"
				where
					"U_CounterSchemeCode" = @list_of_cols_val_tab_del
				and	"U_Status" = N'Y'
				) as prev
				on	isnull(act."U_BPCode",N'#null')			= isnull(prev."U_BPCode",N'#null')
				and	isnull(act."U_Transaction",N'#null')	= isnull(prev."U_Transaction",N'#null')
				and	isnull(act."U_ItemCode",N'#null')		= isnull(prev."U_ItemCode",N'#null')
				and	isnull(act."U_RevisionCode",N'#null')	= isnull(prev."U_RevisionCode",N'#null')
				and	isnull(act."U_Status",N'#null')			= isnull(prev."U_Status",N'#null')
			where
				act."U_CounterSchemeCode" is null
			or	prev."U_CounterSchemeCode" is null
		)
---------------------------------------------------------
		begin
			update
				"@CT_PF_OQCC"
			set
				"U_Status" = N'N'
			where
				"U_CounterSchemeCode" = @list_of_cols_val_tab_del

			insert into
				"@CT_PF_OQCC"
			select
				*
			from
				#OQCC_temp
		end
	end
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if @object_type = N'CT_PF_CtScheme' and @transaction_type = N'A'				--	insert aktualnego
begin
	insert into
		"@CT_PF_OQCC"
	select
		*
	from
		#OQCC_temp
end
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

if @object_type = N'20' and @transaction_type = N'A'							--	zwi�kszenie licznika
begin
	update
		qcc
	set
		qcc."U_Value"				= qcc."U_Value" + 1,
		qcc."U_LastTransaction"		= obj_20."ObjType",
		qcc."U_LastTransactionId"	= obj_20."DocEntry",
		qcc."U_UpdateDate"			= cast(getdate() as date),
		qcc."U_UpdateTime"			= replace(convert(varchar(5), getdate(), 108),':','')
	from
		"@CT_PF_OQCC" as qcc
		inner join
			(
			select
				h."ObjType",
				h."DocEntry",
				h."CardCode",
				l."ItemCode",
				l."U_Revision"
			from
				PDN1 as l
				inner join
					OPDN as h
					on	l."DocEntry" = h."DocEntry"
			where
				h."DocEntry" = @list_of_cols_val_tab_del
			) as obj_20
			on	isnull(qcc."U_BPCode",N'#null')				= case when qcc."U_BPCode" is null then N'#null' else obj_20."CardCode" end
			and	isnull(qcc."U_Transaction",N'#null')		= case when qcc."U_Transaction" is null then N'#null' else obj_20."ObjType" end
			and	isnull(qcc."U_ItemCode",N'#null')			= case when qcc."U_ItemCode" is null then N'#null' else obj_20."ItemCode" end
			and	isnull(qcc."U_RevisionCode",N'#null')		= case when qcc."U_RevisionCode" is null then N'#null' else obj_20."U_Revision" end
	where
		qcc."U_Status" = N'Y'
end
